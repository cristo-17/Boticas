# Estado del proyecto
Actualizado: 2026-09-08 · Última tarea completada: T11 Bloque B (ventas, frontend conectado y verificado en navegador)

## Módulos
| Módulo     | Backend | Frontend | Tests | Notas                              |
|------------|---------|----------|-------|-------------------------------------|
| Caja       | ✅      | ✅ HTTP real | ✅ | Conectada de punta a punta, verificada en navegador |
| Productos  | ✅      | ✅ HTTP real | ✅ | Búsqueda, código de barras, más vendidos — verificado en navegador |
| Inventario | ✅      | ✅ HTTP real | ✅ | Paginado, 4 estados del servidor, registrar lote — verificado en navegador |
| Ventas     | ✅      | ✅ HTTP real | ✅ | Origen de captura + idempotencia + FEFO — verificado en navegador (ver abajo) |
| Merma      | esquema | mock     | —     | Sin Service/Controller aún (Bloque C) |
| Alertas    | esquema | mock     | —     | Sin Service/Controller aún (Bloque C) |
| Auth       | esquema | mock     | —     | `usuarios`/`roles` listos, sin login real (T12) |

## Tarea en curso
**T9 completada y verificada en el navegador de verdad** (no solo
compila, no solo pasa tests): `caja.service.ts` reemplazado por
`HttpClient` sin cambiar su firma; `ConfigService` nuevo consumiendo
`GET /api/config` una sola vez al iniciar (`provideAppInitializer`);
`error.interceptor.ts` con la traducción de códigos y la lista de
silenciosos; `PaginacionComponent` nuevo en `shared/components/`;
`environments/` + `fileReplacements` en `angular.json`.

**Excepción aprobada aplicada:** `cierre.ts`/`cierre.html` rediseñados
para el conteo ciego — ya no muestran "efectivo esperado" antes de
contar (ni como preview mientras se escribe), solo el total de ventas
digitales; el resultado (esperado/contado/diferencia/semáforo) recién
aparece en la respuesta de `POST /cerrar`.

**Constantes movidas a `/api/config`** (ya no hardcodeadas en el
cliente): `TASA_IGV` (`venta.service.ts`, `carrito.service.ts`),
`UMBRAL_STOCK_BAJO` (`inventario.service.ts`, `inventario.ts`),
`UMBRAL_DESCUADRE_LEVE` (`cierre.ts`), `MOTIVOS_MERMA`/
`MOTIVOS_QUE_REQUIEREN_OBSERVACION` (`merma.service.ts`, con el ajuste
mecánico correspondiente en `merma.ts` — inevitable, `inject()` exige
contexto de inyección, no se puede leer un signal desde una constante
de módulo).

**Verificado en el navegador, con el backend real levantado** (Chrome,
sesión con `rosa.quispe`/`1234`), no solo descrito:
- Apertura exitosa: caja creada, datos del backend reflejados
  correctamente (monto, hora, usuario).
- Doble apertura: bloqueada por el propio cliente (ya sabe que hay
  caja abierta); el 409 real ya estaba probado por curl en la Tarea 8.
- Conteo ciego: confirmado en pantalla — "efectivo esperado" no
  aparece en ningún lado antes de cerrar, ni como preview mientras se
  escribe el monto contado. Solo el total de ventas digitales (S/0.00)
  se muestra antes.
- Cierre con descuadre LEVE: `-5.00`, tono ámbar, "esperado/contado"
  revelados recién después de cerrar. Coincide exacto con el cálculo
  del servidor.
- Cierre con descuadre GRAVE: `-50.00`, tono rojo, "el administrador
  recibirá una alerta". Coincide exacto.
- Backend apagado: la petición falla de verdad (confirmado en consola:
  `HttpErrorResponse`), el botón se recupera (ya no se queda
  "cargando" para siempre — bug real encontrado y corregido, ver
  `docs/BITACORA.md` `[FE-006]`), pero **no hay ningún mensaje visible
  para el usuario** — `AperturaComponent` no tiene manejo de error ni
  `<app-toast>` en su plantilla. Es un hueco preexistente del
  frontend (no introducido por esta tarea) y no se resolvió: Apertura
  no está en la lista de excepciones aprobadas a "los componentes no
  se tocan".
- Backend recuperado: reintentar la misma acción funciona sin recargar
  la página.

## Ronda previa a T10 (2026-09-08, tres pedidos del usuario tras aprobar T9)

**1) Regla de error visible por pantalla, ya en CLAUDE.md y aplicada:**
"Toda pantalla que llama a un servicio muestra el estado `error` de ese
servicio" — sección "Reglas de frontend" de CLAUDE.md. Aplicada ahora
mismo en `AperturaComponent` (cerraba la deuda técnica que quedó
abierta en T9) y en `CierreComponent` (`<app-error-banner>` +
`readonly error = this.caja.error` + manejadores de error vacíos en
los `.subscribe()` sueltos de `ngOnInit`/`irAPagina`/
`cargarDatosDeCierre`). Verificado en el navegador con el backend
apagado a propósito: banner rojo visible en ambas pantallas, texto
traducido por `error.interceptor.ts`. Se aplicará por defecto (sin
volver a preguntar) al conectar cada módulo nuevo en la Tarea 11.

**2) Revisión de patrón `[FE-006]` en los demás servicios** (pedida
explícitamente como "no es bug de Caja, es un patrón" — no se corrige
nada todavía, solo se documenta y se deja el molde correcto en
CLAUDE.md, sección "Reglas de frontend" punto 2):

| Servicio | `_error` signal | `cargando` se apaga en |
|---|---|---|
| `producto.service.ts` | ❌ no tiene | solo en `tap()` |
| `venta.service.ts` | ❌ no tiene | solo en `tap()` |
| `merma.service.ts` | ❌ no tiene | solo en `tap()` |
| `alerta.service.ts` | ❌ no tiene | solo en `tap()` |
| `inventario.service.ts` | ✅ tiene | solo en `tap()` (falta `finalize()`) |
| `auth.service.ts` | ❌ no tiene | no tiene `cargando` (login maneja error ad-hoc en la pantalla) |
| `conexion.service.ts` | — exento | no es un recurso de servidor |
| `caja.service.ts` | ✅ tiene | ✅ `finalize()` — ya corregido en T9 |

Los cinco marcados con `tap()` solo van a repetir `[FE-006]` en cuanto
se conecten a HTTP real en la Tarea 11 — se corrigen ahí, no antes,
por instrucción explícita del usuario.

**3) Regla Jackson/Spring Boot ascendida a regla general** (ya no solo
`[BE-002]` en la bitácora): sección "Verificar antes de adivinar" de
CLAUDE.md — verificar clase/enum real del jar instalado antes de
probar variantes de memoria en cualquier propiedad `spring.*`.

**Bug encontrado "por accidente" verificando lo anterior — `[FE-007]`:**
`provideAppInitializer` sin `catchError` deja la app entera en blanco
si `/api/config` falla al arrancar (no es un fallo de pantalla, es un
fallo de bootstrap completo de Angular). Corregido en `app.config.ts`
con `.pipe(catchError(() => of(undefined)))`. Verificado en el
navegador en ambos sentidos: backend apagado desde el arranque → app
carga con banner de error + valores `_DEFECTO` de cada servicio;
backend recuperado → recarga muestra datos reales sin banner, sin
necesidad de tocar código. Detalle en `docs/BITACORA.md` `[FE-007]`.

## Tarea 10 — CERRADA: desplegada y verificada en vivo

**URLs reales:**
- Backend (Render): https://botica-vbzh.onrender.com
- Frontend (Vercel): https://boticas.vercel.app
- Base de datos (Neon): Postgres administrado, sin URL de app pública — acceso vía panel de Neon.

**Verificado en producción real, no solo en local (2026-09-08):**
- `flyway_schema_history`: migraciones `1 - esquema` (21:03:26.597) y
  `2 - seed` (21:03:34.852) aplicadas solas dentro del contenedor de
  Render, sin Maven — `[BE-003]` cerrado con evidencia real. 17 tablas
  de negocio + `flyway_schema_history`.
- Seed de producción correcto: 1 botica, 1 usuario `ADMINISTRADOR`,
  cero datos de demostración (conteo de usuarios/boticas pendiente de
  confirmación final del usuario, ya en camino).
- Zona horaria correcta desde un servidor en UTC (primera prueba real
  fuera de una máquina ya en hora de Lima): registro creado a las
  21:25:06 hora de Lima quedó en Neon como `2026-09-09
  02:25:06.241996+00`; `AT TIME ZONE 'America/Lima'` lo devuelve
  exacto.
- **La frontera de Flyway ya se cruzó** (2026-09-08 21:03:34, hora de
  la migración `2 - seed`): desde ahí ninguna migración aplicada se
  toca — todo cambio de esquema es una migración nueva. Regla
  correspondiente ya en CLAUDE.md ("Producción: solo migraciones
  versionadas"). Detalle completo: `docs/DESPLIEGUE.md`.
- `[OPS-001]` (CORS roto por sintaxis de Markdown pegada en
  `CORS_ORIGEN`) encontrado y corregido en el primer deploy real.
- Contraseña de Neon rotada por el usuario tras una filtración
  accidental (captura de pantalla) — confirmado que el servicio siguió
  sano después del cambio (lectura y escritura real contra la DB).

**Deuda explícitamente aceptada, no son bugs:**
- Login rechaza al usuario real del seed de prod — `auth.service.ts`
  sigue 100% mock (`password: '1234'` hardcodeado, sin HTTP). Se
  resuelve en la Tarea 12.
- Dos datos de botica quemados en el frontend, ambos por la misma
  causa: `features/login/login.html:7` (texto estático) y
  `core/services/auth.service.ts:14` (campo `sede` del usuario mock,
  pintado en el header tras login). Se resuelven solos en la Tarea 12
  cuando la sesión real traiga estos datos del backend. No se tocan
  antes.

## Tarea 10 (histórico de la preparación previa al deploy)

**Infraestructura:** Render (backend) + Vercel (frontend) + Neon
(Postgres), decisión final del usuario. Detalle y alternativa
descartada (Supabase): `docs/DECISIONES.md`. Guía completa de
configuración, límites del plan gratuito y procedimiento de demo:
`docs/DESPLIEGUE.md`.

**Preparado y verificado en este entorno (no solo escrito):**
- `frontend/vercel.json` (rewrite SPA) y service worker de producción
  (`ng add @angular/pwa`) — build de producción confirmado generando
  `ngsw-worker.js`/`ngsw.json`; tests (`npm test`) y build (`npm run
  build`) verdes tras el cambio de dependencias.
- `backend/Dockerfile` multistage — imágenes base verificadas en
  Docker Hub antes de escribirlas, no en memoria. **No verificado con
  `docker build` local** (no hay Docker instalado en este entorno) —
  el primer build real va a ser en Render.
- Conexión a Neon verificada contra su documentación actual antes de
  configurar nada: un solo datasource, endpoint **directo** (no el
  pooler) para Flyway y para la app — detalle y motivo en
  `docs/DESPLIEGUE.md`.
- **Hallazgo importante corregido:** Flyway nunca corría solo al
  arrancar Spring Boot, solo vía el plugin de Maven (`[BE-003]`,
  `docs/BITACORA.md`) — habría dejado la base de Render vacía en el
  primer deploy. Agregado `spring-boot-starter-flyway`; reverificado
  empíricamente (clean + arrancar sin `flyway:migrate` manual) que
  ahora sí migra sola.
- **Seed dev/prod separado**, aplicado y verificado de punta a punta
  contra una base limpia real (no solo que compile): perfil por
  defecto sigue sembrando los datos de demostración de siempre
  (`db/seed/dev/`); perfil `prod` (`db/seed/prod/`, activado con
  `SPRING_PROFILES_ACTIVE=prod`) crea solo 1 botica + 1 usuario
  `ADMINISTRADOR`, **cero** productos/lotes/ventas de muestra, valores
  reales inyectados por variable de entorno vía placeholders de
  Flyway. Confirmado con consultas SQL directas tras el arranque:
  conteos exactos (1/1/0/0), turno con tilde correcto (bug de
  visualización de la terminal descartado comparando contra el
  literal en una consulta aparte). Suite completa de tests del backend
  (23 tests) verde después de todos estos cambios.
- Tests de frontend y backend, y compilación de ambos, verificados
  tras todo lo anterior — todo pasa.

## Tarea 11 Bloque A — CERRADA: productos e inventario

**Dos decisiones de contrato resueltas antes de escribir código** (el
agente encontró dos huecos reales al implementar y preguntó en vez de
inventar — D5/D6, `docs/DECISIONES.md`):
- D5: `productos.unidad_nombre` (columna nueva, `V3`, sin `DEFAULT`).
  `PresentacionResponse` pierde el campo `detalle` compuesto —
  `factorConversion`/`unidadNombre` viajan separados, el frontend arma
  la frase.
- D6: `Producto.alertaVencimiento` (texto ya armado) se reemplaza por
  `estadoVencimiento`/`fechaVencimiento`, mismo patrón que `Lote` — del
  lote FEFO más próximo **con stock > 0**.

**Backend, verificado con `curl` contra una base real** (no solo que
compile): `GET /api/productos?buscar=`, `GET /api/productos/codigo/{cb}`
(404 si no existe), `GET /api/productos/mas-vendidos` (ranking real por
`SUM(cantidad)` contra la data de ventas del seed), `GET /api/lotes`
(paginado, filtros de categoría/vencimiento/stockBajo/productoId,
lista blanca de `orden`), `POST /api/lotes` (con `costoUnitario`,
nunca expuesto de vuelta). 40 tests backend (17 nuevos), todos verdes.
Aislamiento multi-botica probado (`LoteDaoAislamientoTest`).

**Frontend conectado a HTTP real, verificado en el navegador:**
`producto.service.ts`/`inventario.service.ts` con el molde de
`[FE-006]` (`cargando` en `finalize()`, `error` en `catchError()`).
`InventarioScreen` rediseñado: paginación real (`app-paginacion`),
5 chips de vencimiento (4 estados + "Todos"), banner de error, y un
formulario nuevo "Registrar lote" (modal con producto/código/fecha/
stock/ubicación/costo) — probado de punta a punta en el navegador:
crear un lote real subió el contador de 48 a 49 y refrescó la lista.

**Efecto dominó controlado** (Producto/Lote pasan de `id: string` a
`id: number` con HTTP real): `venta.service.ts`, `merma.service.ts`/
`merma.ts`, `carrito.service.ts`, `presentacion-modal.ts`/`.html`,
`punto-venta.ts`/`.html` — todos siguen 100% mock, se les hicieron solo
los ajustes mecánicos mínimos para seguir compilando y funcionando
igual que antes (conversión `String()`/`Number()` en el borde, ver
comentarios en cada archivo) — nada de su diseño ni su flujo cambió.
Verificado en el navegador: Punto de Venta y el modal de presentación
siguen funcionando (badge de vencimiento y "20 tabletas"/"10 tabletas"
compuestos correctamente).

`estadoFefo`/`EstadoFefo` de `fecha.util.ts` — sin consumidor,
borrados. `textoAlertaVencimiento()` nuevo en `fecha.util.ts`,
compartido por Producto (antes duplicado en dos archivos).

## Antes de Bloque B: consolidación de la frontera number/string

Auditoría explícita pedida por el usuario tras el Bloque A: los ids
que llegan del backend (`Producto`/`Lote.id`) son `number`, pero las
conversiones a/desde `string` habían quedado dispersas en tres
convenciones distintas (`String()` en `carrito.service.ts`, `Number()`
en `merma.service.ts`). Consolidado: **la conversión ocurre UNA sola
vez, en el único borde real que la exige** — un `<select>` nativo del
DOM (que solo puede devolver `string`), no el borde HTTP. `merma.ts`
pasó de `FormControl<string>` a signals de `number` con dos únicos
puntos de conversión (`onProductoSeleccionado`/`onLoteSeleccionado`);
`LineaCarrito`, `ItemVenta`, `Merma`/`NuevaMermaRequest` pasan a
`number` en toda la cadena. Regla agregada a CLAUDE.md ("Reglas de
frontend", punto 3). Verificado: build limpio, `npm test` verde, y en
el navegador (Merma sigue funcionando igual, cascada producto→lote y
registro de merma probados de punta a punta).

## Tarea 11 Bloque B — backend CERRADO y verificado con evidencia real

`POST /api/ventas`: idempotencia, validación de caja abierta, FEFO con
`SELECT ... FOR UPDATE`, precio/costo congelados, IGV extraído,
movimientos de caja y stock. Los siete escenarios pedidos, verificados
con `curl` + SQL directo contra una base real (no solo tests):

1. **Reparto FEFO entre dos lotes:** venta de 20 unidades con solo 15
   disponibles en el lote más próximo a vencer — confirmado 2 filas de
   `venta_detalle` (15 + 5), stock de ambos lotes decrementado exacto.
2. **Stock insuficiente + rollback:** pedido de 10 con 3 disponibles →
   `422 STOCK_INSUFICIENTE`; stock verificado sin cambios después (no
   quedó a medias) y cero filas nuevas en `ventas`.
3. **Idempotencia:** mismo `claveIdempotencia` enviado dos veces →
   segunda respuesta idéntica a la primera (`200`, mismo id), solo 1
   fila en `ventas`.
4. **Sin caja abierta:** caja cerrada, venta rechazada con
   `409 SIN_CAJA_ABIERTA`.
5. **Precio y costo congelados:** cambiado el precio del catálogo y el
   costo del lote por SQL directo después de una venta ya registrada
   — la fila de `venta_detalle` ya creada siguió mostrando los valores
   viejos, sin verse afectada por el cambio.
6. **Invariante de totales:** venta con 2 líneas de productos
   distintos — `SUM(venta_detalle.total_linea)` igual a
   `ventas.total`, exacto (verificado por SQL, no por redondeo
   aproximado — la última fila de cada reparto FEFO se lleva el resto
   exacto en vez de redondear independiente).
7. **IGV extraído, no sumado:** total 11.00 → subtotal 9.32, igv 1.68
   (11.00 ÷ 1.18, no 11.00 × 1.18).

**Concurrencia real bajo `SELECT ... FOR UPDATE`:** dos `POST`
disparados en paralelo (`curl` en background, ~30ms de diferencia)
contra el mismo lote con stock para solo uno de los dos — una tuvo
éxito, la otra `422` con el stock ya decrementado por la primera;
stock final exacto (2 = 10 − 8), una sola venta nueva creada. Además,
un test de integración automatizado (`VentaConcurrenciaTest`, dos
hilos con dos transacciones reales, sin `@Transactional` en la clase)
reproduce lo mismo de forma repetible en cada build — no depende de
que el manual haya salido bien una vez.

## Dos verificaciones más, pedidas antes de aprobar el frontend

**A) Rollback multilínea real:** venta de 2 líneas, la primera con
stock suficiente (se procesa y descuenta primero), la segunda sin
stock. `422 STOCK_INSUFICIENTE`, y el stock de AMBOS productos quedó
exactamente igual que antes — verificado por SQL, no solo por la
respuesta HTTP. El caso que de verdad importa: si la transacción
estuviera mal delimitada, la primera línea habría dejado inventario
fantasma sin ninguna venta que lo explique.

**B) Idempotencia bajo concurrencia real — encontró un bug, ya
corregido (`[BE-004]`, `docs/BITACORA.md`):** dos peticiones con la
MISMA `claveIdempotencia` en paralelo (el caso real: la red se corta,
el cliente reintenta mientras la primera todavía se procesa) daban
`500 ERROR_INTERNO` en vez de la venta ya registrada — el `SELECT` de
idempotencia y el `INSERT` no estaban protegidos entre sí, y Postgres
deja la transacción "abortada" tras el `INSERT` fallido, así que ni
siquiera el `SELECT` de recuperación dentro del mismo método podía
correr. Corregido separando el cuerpo transaccional
(`VentaTransaccion.ejecutar`) del punto de entrada público
(`VentaService.registrar`, sin `@Transactional`) — la excepción de
unicidad ahora cruza el proxy de Spring, dispara un rollback real
(stock incluido) y recién ahí `VentaService` vuelve a consultar.
Verificado con 6 peticiones HTTP concurrentes reales (mismo resultado
que antes del fix habría sido: varios 500) y con un test automatizado
de dos hilos, ambos repetidos 5 veces sin fallar.

56 tests backend (16 nuevos de Ventas), todos verdes.

## Tarea 11 Bloque B — frontend CERRADO y verificado en navegador

`venta.service.ts` conectado a `POST /api/ventas` con el molde
`[FE-006]` (`cargando`/`finalize()`, `error`/`catchError()`);
`claveIdempotencia` vive en un signal privado del servicio, se genera
la primera vez que se llama `registrarVenta()` tras vaciar el carrito
(no dentro del `POST`), se reusa en cada reintento y solo se limpia en
`tap()` tras una respuesta exitosa. `carrito.service.ts` gana
`origenCaptura` por línea (`LineaCarrito`, tercer parámetro de
`agregar()`). `PuntoVentaScreen`: `origenSeleccionActual` (signal
privado) se fija en `simularEscaneo()` (`'ESCANEO'`) y en
`elegirProducto()` (`'MANUAL'` solo si el texto tecleado coincide
exacto con `codigoBarras` del producto elegido, `'BUSQUEDA'` en
cualquier otro caso), viaja con la línea recién al agregarla al
carrito. Banner de error combinado (`productoService.error() ??
ventaService.error()`), excepción aprobada de tocar el componente.

**Verificado en el navegador con el backend real** (no solo compila,
no solo pasa tests):
- Carrito con tres líneas, una por cada origen: **Amoxicilina** vía
  búsqueda por nombre (BUSQUEDA), **Clotrimazol** vía "Simular
  escaneo" (ESCANEO), **Paracetamol** tecleando su código de barras
  exacto en el buscador y eligiéndolo de los resultados (MANUAL).
- Cobrar: petición real interceptada del lado del navegador (no
  inspección de código) — el cuerpo enviado a `POST /api/ventas` fue
  `items: [{productoId:2,...,origenCaptura:"BUSQUEDA"}, {productoId:7,
  ...,origenCaptura:"ESCANEO"}, {productoId:1,...,origenCaptura:
  "MANUAL"}]`, cada línea con el origen correcto y **sin ningún campo
  de monto** — solo `productoId`/`presentacionId`/`cantidad`/
  `origenCaptura` (regla del usuario: "el cliente manda cantidades y
  presentaciones, nunca montos"). Respuesta 200, toast "Venta cobrada",
  carrito vaciado.
- Repetido una segunda vez con un carrito distinto: mismo resultado,
  200 + carrito vaciado.

**Hallazgo durante la verificación, no corregido todavía —
`[FE-008]`:** al escribir rápido un código de barras completo en el
buscador, la pantalla se quedó mostrando el catálogo entero en vez de
solo el producto correcto, aunque la petición HTTP con el texto
completo sí había llegado bien al backend (confirmado con `curl`
aparte). Causa: la búsqueda dispara una petición por tecla sin
`debounceTime`/`switchMap`, así que una respuesta de una búsqueda más
corta puede llegar después que la de la búsqueda completa y pisarla.
Se pudo continuar la verificación fijando el valor del campo de una
sola vez (sin escribir tecla por tecla) para confirmar que la
detección MANUAL en sí funciona correctamente contra la petición
correcta — pero el bug de la carrera de peticiones queda documentado
en `docs/BITACORA.md` `[FE-008]`, sin corregir, a la espera de que el
usuario decida cuándo entra.

**No se reinició la base de datos local tras esta verificación** (quedaron
2 ventas de prueba en `botica_db` local) — las credenciales de la
conexión local (`DB_USERNAME`/`DB_PASSWORD`) no estaban disponibles en
este turno para correr `flyway:clean`. No afecta producción (Neon,
credenciales distintas, sin tocar). Pendiente: el usuario decide si
limpia la base local o la deja así para la próxima sesión.

## Esperando decisión mía
Ninguna nueva. Frontend de Ventas conectado y verificado; el bug
`[FE-008]` (carrera de peticiones en la búsqueda) queda documentado
pero explícitamente sin corregir hasta que el usuario lo pida.

## Siguiente paso concreto
Esperando aprobación del usuario para el Bloque C (Merma/Alertas) o
para decidir si `[FE-008]` se corrige antes.

## Deuda técnica aceptada
- `merma`, `alerta` sin `_error` signal y con `cargando` apagado solo
  en `tap()` — heredan `[FE-006]` en cuanto se conecten a HTTP real
  (Bloque C). `venta.service.ts` sigue 100% mock, pendiente de
  conectar al backend ya listo.
- Merma, Alertas y Auth siguen 100% mock — Bloque C y T12.
- `GET /api/ventas?fecha=hoy` declarado en `VentaDao` pero sin
  Controller — nadie lo consume todavía, se expone cuando haga falta
  (mismo criterio que `listarMovimientos`).
- Bundle inicial del frontend excede el budget de 500kB (warning, no
  error) — no crítico, sigue creciendo con cada módulo conectado.

## Fase 2 (fuera de esta fase, no se construye ahora)
- **Pantalla de reportes de resultados**. Dato ya capturado desde la
  Tarea 7. Endpoint restringido a `ADMINISTRADOR`, sin definir todavía.
- Comprobantes electrónicos (SUNAT), Kardex, reportes DIGEMID, lotes
  fraccionados: tablas ya creadas vacías en `V1__esquema.sql`.
